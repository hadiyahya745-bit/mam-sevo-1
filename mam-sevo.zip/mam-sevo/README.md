# Mam Sevo - Kurdish voice assistant

- `public/index.html`  the website (single file)
- `api/chat.js`        server function that calls OpenAI (keeps the key secret)
- Environment variable: `OPENAI_API_KEY` (required), `OPENAI_MODEL` (optional)

Deploy: push this folder to GitHub, import it on vercel.com, add OPENAI_API_KEY, deploy.
Or: `npx vercel` then `npx vercel env add OPENAI_API_KEY` then `npx vercel --prod`.
