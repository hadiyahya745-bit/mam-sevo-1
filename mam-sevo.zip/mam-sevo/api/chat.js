// Vercel serverless function: POST /api/chat
// Keeps your OpenAI key on the server (environment variable OPENAI_API_KEY).

const SYS =
  "Your name is Mam Sevo (مام سێڤۆ): a kind, wise, warm elderly Kurdish man who loves to help. You are a helpful voice assistant. Always reply in clear, natural Kurdish Sorani written in Arabic Kurdish script. Keep answers concise unless the user asks for detail. Be polite and helpful.";
const VOICE_NOTE =
  " Your reply is read aloud, so use plain sentences with no markdown, bullet symbols or emojis.";
const NOTES = {
  ckb: " Never use Latin script for Kurdish; use Arabic Kurdish script only.",
  bdn: " The user selected Kurdish Badini (Kurmanji dialect), so IGNORE the instruction about Sorani and Arabic script: reply in clear, natural Badini Kurmanji written in Latin (Hawar) script.",
  ar: " The user selected Arabic, so reply in clear Modern Standard Arabic instead.",
  en: " The user selected English, so reply in clear English instead.",
};

// Very simple per-IP limit (best effort; resets when the server instance restarts).
const hits = new Map();
function limited(ip) {
  const now = Date.now();
  if (hits.size > 5000) hits.clear();
  const recent = (hits.get(ip) || []).filter((t) => now - t < 60000);
  recent.push(now);
  hits.set(ip, recent);
  return recent.length > 20; // max 20 requests per minute per IP
}

module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).json({ error: "bad" });

  const key = process.env.OPENAI_API_KEY;
  if (!key) return res.status(500).json({ error: "key" });

  const ip = String(req.headers["x-forwarded-for"] || "unknown").split(",")[0].trim();
  if (limited(ip)) return res.status(429).json({ error: "rate" });

  let body = req.body;
  if (typeof body === "string") {
    try { body = JSON.parse(body); } catch { body = null; }
  }
  const lang = body && NOTES[body.language] !== undefined ? body.language : "ckb";
  const raw = body && Array.isArray(body.messages) ? body.messages : [];

  const history = raw
    .filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string" && m.content.trim())
    .slice(-12)
    .map((m) => ({ role: m.role, content: m.content.slice(0, 2000) }));

  if (!history.length || history[history.length - 1].role !== "user") {
    return res.status(400).json({ error: "bad" });
  }

  try {
    const r = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + key },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        max_completion_tokens: 700,
        messages: [{ role: "system", content: SYS + NOTES[lang] + VOICE_NOTE }, ...history],
      }),
    });
    if (r.status === 401) return res.status(500).json({ error: "key" });
    if (r.status === 429) return res.status(429).json({ error: "rate" });
    if (!r.ok) {
      console.error("OpenAI error", r.status, await r.text().catch(() => ""));
      return res.status(502).json({ error: "server" });
    }
    const data = await r.json();
    const reply = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
    if (!reply || !reply.trim()) return res.status(502).json({ error: "server" });
    return res.status(200).json({ reply: reply.trim() });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: "server" });
  }
};
